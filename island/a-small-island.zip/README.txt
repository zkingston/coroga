A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/EPaJdL.

 Randomly generated 3D islands
Press "generate new" for a new random island.

Click and drag to rotate view, and zoom with scrollwheel
Curently featuring;
- Hills
- Water
- Trees
- Mountains
- Clouds

Note: Trees take the longest time to calculate, so uncheck trees for faster generation time.

Inspiration taken from pens by http://codepen.io/Yakudoo 


Forked from [Christian Östman](http://codepen.io/chribbe/)'s Pen [A Small Island](http://codepen.io/chribbe/pen/LVwgJE/).